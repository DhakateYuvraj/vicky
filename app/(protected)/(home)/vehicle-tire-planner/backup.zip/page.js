'use client';

import { Container, Card, ButtonGroup, Button } from 'react-bootstrap';
import { useState } from 'react';
import VehicleFlow from './_components/VehicleFlow';

export default function VehicleLayoutPage() {
  const [type, setType] = useState('CAR');

  return (
    <Container fluid className="py-4">
      <Card className="shadow-sm">
        <Card.Header className="bg-white d-flex justify-content-between">
          <strong>Vehicle Tire Planner (Top View)</strong>

          <ButtonGroup size="sm">
            <Button
              variant={type === 'CAR' ? 'primary' : 'outline-primary'}
              onClick={() => setType('CAR')}
            >
              Car
            </Button>
            <Button
              variant={type === 'TRUCK' ? 'primary' : 'outline-primary'}
              onClick={() => setType('TRUCK')}
            >
              Truck
            </Button>
          </ButtonGroup>
        </Card.Header>

        <Card.Body style={{ height: 600 }}>
          <VehicleFlow type={type} />
        </Card.Body>
      </Card>
    </Container>
  );
}
