// components/reactflow/nodes/TireNode.jsx
export default function TireNode({ data }) {
  return (
    <div
      onClick={() => alert(`Tire clicked: ${data.label}`)}
      style={{
        width: 56,
        height: 36,
        borderRadius: 6,
        background: '#111827',
        border: '3px solid #374151',
        color: 'white',
        fontSize: 10,
        fontWeight: 700,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        cursor: 'pointer',
      }}
    >
      {data.label}
    </div>
  );
}
