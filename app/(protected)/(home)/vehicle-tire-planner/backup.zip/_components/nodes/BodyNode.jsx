export default function BodyNode({ data }) {
  return (
    <div
      style={{
        width: data.width,
        height: data.height,
        borderRadius: 18,
        background: '#e5e7eb',
        border: '2px solid #64748b',
      }}
    />
  );
}
