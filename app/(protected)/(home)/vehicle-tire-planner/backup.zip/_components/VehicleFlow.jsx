'use client';

import { useEffect } from 'react';
import ReactFlow, {
  Background,
  Controls,
  useNodesState,
  useEdgesState,
} from 'reactflow';
import 'reactflow/dist/style.css';

import TireNode from './nodes/TireNode';
import LabelNode from './nodes/LabelNode';
import { carFixedLayout } from './layouts/car.top.layout';
import { truckFixedLayout } from './layouts/truck.top.layout';

const nodeTypes = {
  tire: TireNode,
  label: LabelNode,
};

export default function VehicleFlow({ type }) {
  const layout = type === 'CAR' ? carFixedLayout : truckFixedLayout;

  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);

  // Reset layout on switch
  useEffect(() => {
    setNodes(layout.nodes);
    setEdges([]); // no edges for now
  }, [type]);

  return (
    <ReactFlow
      nodes={nodes}
      edges={edges}
      nodeTypes={nodeTypes}
      nodesDraggable={false}
      nodesConnectable={false}
      elementsSelectable
      zoomOnScroll={false}
      panOnDrag={false}
      fitView
    >
      <Background gap={24} />
      <Controls showInteractive={false} />
    </ReactFlow>
  );
}
