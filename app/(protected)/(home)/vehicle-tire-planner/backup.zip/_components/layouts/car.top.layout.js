// components/reactflow/layouts/car.fixed.layout.js
export const carFixedLayout = {
  nodes: [
    // Direction labels
    { id: 'front', type: 'label', position: { x: 60, y: 240 }, data: { text: 'Front' }, draggable: false },
    { id: 'back', type: 'label', position: { x: 420, y: 240 }, data: { text: 'Back' }, draggable: false },
    { id: 'left', type: 'label', position: { x: 240, y: 80 }, data: { text: 'Left' }, draggable: false },
    { id: 'right', type: 'label', position: { x: 240, y: 380 }, data: { text: 'Right' }, draggable: false },

    // Car tires (Left)
    { id: 'FL', type: 'tire', position: { x: 180, y: 180 }, data: { label: 'FL' }, draggable: false },
    { id: 'RL', type: 'tire', position: { x: 280, y: 180 }, data: { label: 'RL' }, draggable: false },

    // Car tires (Right)
    { id: 'FR', type: 'tire', position: { x: 180, y: 300 }, data: { label: 'FR' }, draggable: false },
    { id: 'RR', type: 'tire', position: { x: 280, y: 300 }, data: { label: 'RR' }, draggable: false },

    // Spare (right side)
    { id: 'SP1', type: 'tire', position: { x: 420, y: 240 }, data: { label: 'SP1' }, draggable: false },
  ],
};
