// components/reactflow/layouts/truck.fixed.layout.js
export const truckFixedLayout = {
  nodes: [
    // Direction labels
    { id: 'front', type: 'label', position: { x: 60, y: 250 }, data: { text: 'Front' }, draggable: false },
    { id: 'back', type: 'label', position: { x: 520, y: 250 }, data: { text: 'Back' }, draggable: false },
    { id: 'left', type: 'label', position: { x: 300, y: 60 }, data: { text: 'Left' }, draggable: false },
    { id: 'right', type: 'label', position: { x: 300, y: 440 }, data: { text: 'Right' }, draggable: false },

    // Truck tires (Left side)
    { id: 'S1-L', type: 'tire', position: { x: 180, y: 180 }, data: { label: 'S1-L' }, draggable: false },
    { id: 'D1-L', type: 'tire', position: { x: 260, y: 180 }, data: { label: 'D1-L' }, draggable: false },
    { id: 'D2-L', type: 'tire', position: { x: 340, y: 180 }, data: { label: 'D2-L' }, draggable: false },

    // Truck tires (Right side)
    { id: 'S1-R', type: 'tire', position: { x: 180, y: 300 }, data: { label: 'S1-R' }, draggable: false },
    { id: 'D1-R', type: 'tire', position: { x: 260, y: 300 }, data: { label: 'D1-R' }, draggable: false },
    { id: 'D2-R', type: 'tire', position: { x: 340, y: 300 }, data: { label: 'D2-R' }, draggable: false },

    // Spares (stacked on right)
    { id: 'SP1', type: 'tire', position: { x: 520, y: 160 }, data: { label: 'SP1' }, draggable: false },
    { id: 'SP2', type: 'tire', position: { x: 520, y: 220 }, data: { label: 'SP2' }, draggable: false },
    { id: 'SP3', type: 'tire', position: { x: 520, y: 280 }, data: { label: 'SP3' }, draggable: false },
    { id: 'SP4', type: 'tire', position: { x: 520, y: 340 }, data: { label: 'SP4' }, draggable: false },
  ],
};
